﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace Uni_Garage1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void submit_Click(object sender, EventArgs e)
        {
            string username = Username.Text.Trim();
            string password = Password.Text.Trim();
            password = ComputeSha256Hash(password);
            //if (!Regex.IsMatch(username, @"^[a-zA-Z0-9_]{3,20}$"))
            //{
            //    throw new Exception("Invalid username.");
           // }
           // else
           // {
                SqlConnection Conn = new SqlConnection("Server=localhost; Database=uni_garage; integrated security=true;");

               
                try
                {
                    Conn.Open();  // Ensure the connection is open before executing the query

                    //string query = "SELECT StaffID FROM LoginStaff WHERE Username = @username AND Login_Password = @password";
                    string query = "SELECT * FROM LoginStaff WHERE Username = '" + username + "' AND Login_Password = '" + password + "'";
                    using (SqlCommand cmd = new SqlCommand(query, Conn))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                MessageBox.Show("Login successful. Welcome " + reader["StaffID"]);

                                NewEnrtry newentry = new NewEnrtry();
                                newentry.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Invalid username or password.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Login failed: " + ex.Message);
                }
                finally
                {
                    Conn.Close();
                }
            //}
        }

        public static string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2")); // convert to hexadecimal
                }
                return builder.ToString();
            }
        }
    }
}
