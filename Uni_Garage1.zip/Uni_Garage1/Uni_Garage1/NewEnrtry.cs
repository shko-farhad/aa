﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Uni_Garage1
{
    public partial class NewEnrtry : Form
    {
        public NewEnrtry()
        {
            InitializeComponent();
        }

        private void insert_Click(object sender, EventArgs e)
        {
            SqlConnection Conn = new SqlConnection("Server=localhost; Database=uni_garage; integrated security=true;");

            try
            {
                Conn.Open();

                string query = "INSERT INTO STAFF (StaffName, UniID,PhoneNumber, Email, DateOfRegistry)" + "VALUES (@StaffName,@Uni_ID,@PhoneNumber,@Email, Getdate())";

                SqlCommand sqlCommand = new SqlCommand(query, Conn);
                sqlCommand.Parameters.AddWithValue("@StaffName", Name1.Text);
                sqlCommand.Parameters.AddWithValue("@Uni_ID", UniID.Text);
                sqlCommand.Parameters.AddWithValue("@PhoneNumber", Phone.Text);
                sqlCommand.Parameters.AddWithValue("@Email", Email.Text);

                sqlCommand.ExecuteNonQuery();

                MessageBox.Show("New entry was done successfully!");

            }
            catch (Exception ex)
            {

                MessageBox.Show("Error while entering new record!" + ex.Message);
            }

            finally
            {
                Conn.Close();

            }
        }
    }
}
