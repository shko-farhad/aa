﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Uni_Garage1
{
    public partial class Form2 : Form
    {
        SqlConnection Conn = new SqlConnection("Server=localhost; Database=uni_garage; Integrated Security=true;");
        DataTable dt = new DataTable();
        public Form2()
        {
            InitializeComponent();
            dataGridView1.ReadOnly = false;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2;
            dataGridView1.CellEndEdit += UpdateClass;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           

            if (Conn.State == ConnectionState.Closed)
            {
                Conn.Open();
            }

            string search = textBox1.Text;
            SqlDataAdapter adapter = new SqlDataAdapter("select StaffID, StaffName, UniID,PhoneNumber, Email, DateOfRegistry from Staff WHERE StaffName LIKE @search", Conn);
            adapter.SelectCommand.Parameters.AddWithValue("@search", "%" + search + "%");
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;

            Conn.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void UpdateClass(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // Get the edited row
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Get the primary key (StaffID)
                string idValue = row.Cells["StaffID"].Value.ToString();

                if (idValue == null || string.IsNullOrEmpty(idValue))
                    return;

                // Get updated values from the row
                string staffName = row.Cells["StaffName"].Value.ToString();
                string uniID = row.Cells["UniID"].Value.ToString();
                string phoneNumber = row.Cells["PhoneNumber"].Value.ToString();
                string email = row.Cells["Email"].Value.ToString();

                using (SqlCommand cmd = new SqlCommand("UPDATE Staff SET StaffName = @StaffName, UniID = @UniID, PhoneNumber = @PhoneNumber, Email = @Email WHERE StaffID = @StaffID", Conn))
                {
                    cmd.Parameters.AddWithValue("@StaffName", staffName ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@UniID", uniID ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Email", email ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@StaffID", idValue);

                    Conn.Open();
                    cmd.ExecuteNonQuery();
                    Conn.Close();
                }

                MessageBox.Show("Update successful.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating database: " + ex.Message);
                if (Conn.State == ConnectionState.Open)
                    Conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
             
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Assuming StaffID is in the first column (change index or use column name if needed)
                    var staffID = dataGridView1.SelectedRows[0].Cells["StaffID"].Value;

                    DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        try
                        {
                            using (SqlCommand cmd = new SqlCommand("DELETE FROM Staff WHERE StaffID = @StaffID", Conn))
                            {
                                cmd.Parameters.AddWithValue("@StaffID", staffID);
                                Conn.Open();
                                cmd.ExecuteNonQuery();
                                Conn.Close();

                                // Refresh the grid (optional)
                                dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                                MessageBox.Show("Record deleted successfully.");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error deleting record: " + ex.Message);
                            if (Conn.State == ConnectionState.Open)
                                Conn.Close();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select a row to delete.");
                }
             

        }
    }
}
